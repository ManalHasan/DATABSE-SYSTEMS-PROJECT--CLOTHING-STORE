Please enter your servers's username and password, for connecting the database

Edit the path of the stylesheets for displaying pictures.